Bo du lieu anh vet thuong da duoc bac si gan nhan va xac nhan (loai anh, vien vet, 5 tinh chat, muc tin cay, chat luong Dat).
Ten tep: <ma_nghien_cuu>_<ma_vet_thuong>_<ma_anh>[_area_<dien_tich>_cm2].png
Chi gom anh da xac nhan nhan, chat luong Dat, khong danh dau Khong su dung, va benh nhan dong y dung du lieu.
Anh PNG la ban ve lai da bo metadata; anh goc va du doan AI ban dau duoc giu rieng trong ung dung.
CSV va labels.json khong co ho ten, dien thoai, nam sinh, ngay chup, ma ho so lam sang hay ghi chu tu do.
labels.json: vien bac si chot (toa do 0..1), muc 5 tinh chat, du doan AI goc, so ngay tu ngay bat dau theo doi vet, thu tu chup, phien ban phac do neu anh chup sau phien.
Cot split: chia train/val/test theo benh nhan.
capture-quality.json: nguon anh, ROI, chat luong thu nghiem va so do tham chieu; khong co ID thiet bi/bac si, thoi gian hay ghi chu tu do.
automatic_area_cm2: uoc luong AR (vung khoanh theo mau + khoang cach + noi tham so camera), CHUA KIEM CHUNG; null neu khong co AR. Nhan chuan la area_reference_cm2 do bac si xac nhan. Nhan synthetic_demo chi la du lieu mo phong.
Xuat luc: 2026-11-24T22:30:51.469Z